#include <stdio.h>
#include <stdbool.h>

int main() {
	int data[20], gen[10], dn, gn, i, j;
	
	//--------Server----------
	printf("------------Server-------------\n\n");
	
	printf("Enter the number of data bits: ");
	scanf("%d", &dn);
	printf("Enter the data bits one by one: ");
	for (i = 0; i < dn; i++)
		scanf("%d", &data[i]);
	
	printf("Enter the degree of generator polynomial: ");
	scanf("%d", &gn);
	gn++;
	printf("Enter the bits of generator polynomial one by one: ");
	for (i = 0; i < gn; i++)
		scanf("%d", &gen[i]);
	
	int dlen = dn + gn - 1;	
	for (i = dn; i < dlen; i++)
		data[i] = 0;
	
	printf("\nData after appending '0' bits: ");
	for (i = 0; i < dlen; i++)
		printf("%d", data[i]);
	printf("\nGenerator polynomial: ");
	for (i = 0; i < gn; i++)
		printf("%d", gen[i]);
	printf("\n\n");
	
	int rem[gn];
	for (i = 0; i < gn; i++)
		rem[i] = data[i];
	
	int pos = gn - 1;
	while (pos < dlen) {
		while (rem[0] == 0) {
			if (pos == dlen-1)
				break;
			for (i = 0; i < gn-1; i++)
				rem[i] = rem[i+1];
			rem[gn-1] = data[++pos];
		}
		if (rem[0] == 0)
			break;
		for (i = 0; i < gn; i++)
			rem[i] ^= gen[i];
			
//		for (i = 0; i < gn; i++)
//			printf("%d", rem[i]);
//		printf("\n");
	}
	
	printf("CRC bits: ");
	for (i = 1; i < gn; i++)
		printf("%d", rem[i]);
		
	for (i = dn, j = 1; i < dlen; i++, j++)
		data[i] = rem[j];
	
	printf("\nData bits after appending CRC bits: ");
	for (i = 0; i < dlen; i++)
		printf("%d", data[i]);
	printf("\n\n");
	
	//--------Client-------------
	printf("------------Client-------------\n\n");
	
	for (i = 0; i < gn; i++)
		rem[i] = data[i];
	
	pos = gn - 1;
	while (pos < dlen) {
		while (rem[0] == 0) {
			if (pos == dlen-1)
				break;
			for (i = 0; i < gn-1; i++)
				rem[i] = rem[i+1];
			rem[gn-1] = data[++pos];
		}
		if (rem[0] == 0)
			break;
		for (i = 0; i < gn; i++)
			rem[i] ^= gen[i];
	}
	
	printf("CRC bits after division: ");
	bool allZero = true;
	for (i = 1; i < gn; i++) {
		if (rem[i] == 1)
			allZero = false;
		printf("%d", rem[i]);
	}
	printf("\n");
	
	if (allZero)
		printf("Since all the CRC bits are zero, there is no error.\n\n");
	else
		printf("The CRC bits are not zero, hence there is error.\n\n");
	
	return 0;
}


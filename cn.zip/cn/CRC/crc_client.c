//JACOB PARACKEL
//3162076

# include<stdlib.h>
# include<netinet/in.h>//The header file in.h contains constants and structures needed for internet domain addresses
# include<time.h>
# include<arpa/inet.h>
# include<string.h>
# include<unistd.h> //read write close functions
# include<netdb.h>
# include<stdio.h>//This header file contains declarations used in most input and output and is typically included in all C programs.
#include<sys/types.h> 
#include<sys/socket.h> 

int  main(int argc, char *argv[])
{ 
	struct sockaddr_in serversocket;
  	int listensocket,i,connsd,size;
	char sendbuff[100];
	int j,keylen,msglen,temp;
	char input[100], key[30],quot[100],rem[30],key1[30];
	
	char n[100],f[8],div[20],nm[20];
	
if (argc < 3) {
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }
        printf("\tThis is Chat Client.\n");
        bzero((char *)&serversocket,sizeof(serversocket));  //The bzero() function copies n bytes, each with a value of zero, into string

        listensocket=socket(AF_INET,SOCK_STREAM,0);//int socket(domain, type, protocol)

        if(listensocket<0)
                printf("Socket Could Not Be Created");
        else
                printf("Socket Created Succesfully");

        printf("\nListensocket Value : %d",listensocket);

        serversocket.sin_family=AF_INET;
        serversocket.sin_port=htons(atoi(argv[2]));
        serversocket.sin_addr.s_addr=INADDR_ANY;
      	i = connect(listensocket,(struct sockaddr *)&serversocket,sizeof(serversocket)); /*The connect() system call connects the socket referred to by the file descriptor sockfd to the address specified by addr. The addrlen argument specifies the size of addr.*/

        if(i==0)
                printf("\nConnect SUCCESS\n");
        else
                printf("\nConnect ERROR\n");
	
	

	printf("Enter Data: ");
	gets(n);

	printf("Enter Key: ");
	gets(div);

	keylen=strlen(div);
	msglen=strlen(n);

	strcpy(key1,key);

	
	for (i=0;i<keylen-1;i++)
	{
		n[msglen+i]='0';
	}

	for (i=0;i<msglen;i++)
		nm[i]=n[i];

	for (i=0;i<msglen;i++)
	{
		temp=i;
		if(n[i]=='1')
		{
			for (j=0;j<keylen;j++)
			{
				if(n[temp]==div[j])
				{
					n[temp]='0';
					f[j]='0';
				}
				else
				{
					n[temp]='1';
					f[j]='1';
				}
				temp++;
			}
			
		quot[i]='1';
		}
		else
		quot[i]='0';
		
	}
	
	printf("\nNumber is ");
	for (i=0;i<msglen;i++)
	printf("%c",nm[i]);
     
	
	printf("\nQuotient is ");
	for (i=0;i<msglen;i++)
	printf("%c",quot[i]);
     
	printf("\nRemainder is ");
	for (i=0;i<keylen;i++)
	printf("%c",f[i]);
	
	
	bzero(sendbuff,100);
	printf("\nFinal data is: ");
	for (i=0;i<msglen;i++)
	{
	printf("%c",nm[i]);
	sendbuff[i]=nm[i];
	}
	
	for (i=0,j=msglen;i<keylen;j++,i++)
	{
	printf("%c",f[i]);
    	sendbuff[j]=f[i];
    	}
    	
	printf("\nWriting the Final data...\n");
	 write(listensocket,sendbuff,strlen(sendbuff));
	
	
    
 close(listensocket);
}

/*
$ ./cli localhost 5004
	This is Chat Client.
Socket Created Succesfully
Listensocket Value : 3
Connect SUCCESS
Enter Data: 110010101
Enter Key: 10101

Quotient is 111110111
Remainder is 1011
Final data is: 1100101011011
Writing the Final data...


*/


